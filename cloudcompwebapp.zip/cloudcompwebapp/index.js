

String.prototype.hashCode = function() {
    var hash = 0,
      i, chr;
    if (this.length === 0) return hash;
    for (i = 0; i < this.length; i++) {
      chr = this.charCodeAt(i);
      hash = ((hash << 5) - hash) + chr;
      hash |= 0; // Convert to 32bit integer
    }
    return hash;
  }
  

document.getElementById("mybutton").addEventListener("click", hashsomething);
document.getElementById("resetpage").addEventListener("click", reloadPage);

function hashsomething(){
  const unhashedpass = document.getElementById("fname");
  const unhashedpassvalue = unhashedpass.value;
  console.log(unhashedpassvalue, unhashedpassvalue.hashCode())
  var unhashedpassfinalvalue = unhashedpassvalue.hashCode();
  var outputunhash = document.getElementById("lname");
  outputunhash.value = unhashedpassfinalvalue;
  console.log("clicked");
}

function reloadPage(){
    location.reload();
}

